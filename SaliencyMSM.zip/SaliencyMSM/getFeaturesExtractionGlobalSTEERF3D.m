function [STEERF]=getFeaturesExtractionGlobalSTEERF3D(IFrames)

theta = 0:45:315;
sigma=3;

nscales=length(IFrames);
msf=length(IFrames(1).scale);

for scale=1:nscales
    for ph=1:msf % number of frames
        I=IFrames(scale).scale(ph).g;
        %% Steer filter
        for i = [1:length(theta)]
            J= steerGaussFilterOrder1((I),theta(i),sigma,false);
            STEERF(scale).scale(ph).grad(i).value=J;
        end
    end
end
  
   
  
   



