function N=getNumberSuperPixels(nslm1,sizepatch)

N1=prod(nslm1/sizepatch); 
N=floor(N1+median(nslm1));