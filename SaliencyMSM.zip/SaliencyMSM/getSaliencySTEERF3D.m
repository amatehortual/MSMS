function [salSTEERF]=getSaliencySTEERF3D(STEERF,superpixelvec,ref,deltat)

nscales=length(superpixelvec);
nphases=length(STEERF(1).scale);

for scale=1:nscales
    supv=superpixelvec(scale).scale;
    idx = label2idx(supv.L);
    I=STEERF(scale).scale(ref).grad(1).value;
    outputImage = zeros(size(I),'like',I);
    for labelVal=1:supv.N
        redIdx = idx{labelVal};
        for i=1:length(STEERF(scale).scale(ref).grad) % number of orientations
            for ph=1:deltat:nphases % number of frames
                outputImage(redIdx) = outputImage(redIdx)+...
                (STEERF(scale).scale(ref).grad(i).value(redIdx)-STEERF(scale).scale(ph).grad(i).value(redIdx)).^2;
            end
       end
    end
    salSTEERF(scale).value=outputImage;
end
