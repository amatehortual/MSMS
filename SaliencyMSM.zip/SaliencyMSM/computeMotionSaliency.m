function [SaliencyMap]=computeMotionSaliency(sequence,deltat,volsal)

%% Parameters:
% =====>>>> Input:
% sequence:     3D or 4D matrix of the intensity images I(u,T), where the 
%               last column corresponds to the time, i.e., T is 1,...,N, 
%               being N the number of frames and u the spatial coordinates
%               (2D or 3D) 
% deltat:       scalar of the distance between times to be used in the 
%               estimation of the saliency along the sequence. A deltat 
%               equal 1 will use all the sequence, while a value of 2 will 
%               use the half of the data
% volsal:       vector MX1 that contains the indices of the sequence whose 
%               saliency will be estimated 
% =====>>>> Output:
% SaliencyMap:  it is a struct array (SaliencyMap(Ns).value) with the 
%               number of salient volumes (1,...,Ns=length(volsal)) of the 
%               saliency images S(u,volsal) computed for each time of the 
%               temporal sequence volsal 
%% Run

SaliencyMap=[];
nredu=3; 
ms=size(sequence);
dimT=length(ms);
switch dimT
    case 3
        tdim=2;
    case 4
        tdim=3;
    otherwise
        fprintf('Error, sequence must be a 3D or 4D matrix\n')
    return
end

Nframes=ms(dimT);

if tdim==2
    for ph=1:Nframes
        vol1=sequence(:,:,ph);
        vol=mat2gray(single(vol1));
        I = reshape(imadjust(vol(:)),size(vol));
        IFrames(1).scale(ph).g=I; % original scale
        I1=I;
        for ns=1:nredu
            I1 = impyramid(I1, 'reduce');
            IFrames(ns+1).scale(ph).g=I1;
        end
        IFrames(nredu+2).scale(ph).g=impyramid(I, 'expand');
    end
elseif tdim==3
    for ph=1:Nframes
        vol1=sequence(:,:,:,ph);
        vol=mat2gray(single(vol1));
        I = reshape(imadjust(vol(:)),size(vol));
        IFrames(1).scale(ph).g=I; % original scale
        I1=I;
        for ns=1:nredu
            I1 = impyramid(I1, 'reduce');
            IFrames(ns+1).scale(ph).g=I1;
        end
        IFrames(nredu+2).scale(ph).g=impyramid(I, 'expand');
    end
end

fprintf('=====>>> Frames saved \n');

%% saliency

[STEERF]=getFeaturesExtractionGlobalSTEERF3D(IFrames);
fprintf('=====>>> Features extracted \n');

Nframesal=length(volsal);
ph1=1;

if tdim==3
    for ph=volsal
        fprintf('=====>>> Computing saliency frames %d/%d \n',ph1,Nframesal);
        clearvars superpixelvec N
        for ns=1:length(IFrames)
            N(ns)=getNumberSuperPixels(size(IFrames(ns).scale(ph).g),7);
            [Lx,Nx]=superpixels3((IFrames(ns).scale(ph).g),N(ns));
            superpixelvec(ns).scale.L=Lx;
            superpixelvec(ns).scale.N=Nx;
        end
        clearvars salSTEERF MSM
        [salSTEERF]=getSaliencySTEERF3D(STEERF,superpixelvec,ph,deltat);
        MSM=[salSTEERF(1).value];
        sti=size(MSM);

        for ns=2:length(IFrames)
            MSM=MSM+imresize3([salSTEERF(ns).value],sti);
        end
        MSMf=(MSM);
        SaliencyMap(ph1).value=MSMf; 
        ph1=ph1+1;
    end
elseif tdim==2
    for ph=volsal
        fprintf('=====>>> Computing saliency frames %d/%d \n',ph1,Nframesal);
        clearvars superpixelvec N
        for ns=1:length(IFrames)
            N(ns)=getNumberSuperPixels(size(IFrames(ns).scale(ph).g),7);
            [Lx,Nx]=superpixels((IFrames(ns).scale(ph).g),N(ns));
            superpixelvec(ns).scale.L=Lx;
            superpixelvec(ns).scale.N=Nx;
        end
        clearvars salSTEERF MSM
        [salSTEERF]=getSaliencySTEERF3D(STEERF,superpixelvec,ph,deltat);
        MSM=[salSTEERF(1).value];
        sti=size(MSM);

        for ns=2:length(IFrames)
            MSM=MSM+imresize([salSTEERF(ns).value],sti);
        end
        MSMf=(MSM);
        SaliencyMap(ph1).value=MSMf; 
        ph1=ph1+1;
    end
end

